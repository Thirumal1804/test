package routines;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class COMMON {

	     /*
	     * Writes the console output to log file instead of displaying it on console/server log
	     */
	    public static void writeConsoleOutput2Log(String log_filename)
	    {
	            //System. out.println(log_filename.lastIndexOf("/" ));
	      String folderpath=StringHandling. LEFT(log_filename, log_filename.lastIndexOf("/" ));
	      
	      java.io.File folder = new java.io.File(folderpath);
	      if (!folder.exists()) {
	      if (folder.mkdir()) {
	      System. out.println("Directory " +folderpath+" is created!");

	      }
	      else {
	      System. out.println("Failed to create directory at " +folderpath);
	      }
	      }
	      try
	      {
	      java.io.File file = new java.io.File(log_filename);
	      java.io.PrintStream ps = new java.io.PrintStream(new java.io.FileOutputStream(file));
	      System.setErr(ps);
	      System.setOut(ps);
	      }catch(Exception e)
	      {
	            System. out.println("Log file can not be written" );
	      }

	    }
	    
	    public static boolean isChanged(String s1,String s2)
	    {
	    	s1=!Relational.ISNULL(s1) && s1.trim().length()>0?s1.trim():"";
	    	s2=!Relational.ISNULL(s2) && s2.trim().length()>0?s2.trim():"";
	    	if(s1.equals(s2))
	    		return false;
	    	else return true;
	    			
	    }
	    
	   
}
